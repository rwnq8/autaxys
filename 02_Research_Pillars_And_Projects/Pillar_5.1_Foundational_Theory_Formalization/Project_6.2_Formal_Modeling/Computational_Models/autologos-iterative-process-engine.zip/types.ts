

export interface IterationLogEntry {
  iteration: number;
  productSummary: string; // A summary or key aspect of the product at this iteration
  status: string;
  timestamp: number; // Changed from string to number
  fullProduct?: string; // Optional full product for detailed view
  linesAdded?: number;
  linesRemoved?: number;
}

export interface LoadedFile {
  name: string;
  content: string;
}

export type ProcessingMode = 'exploratory' | 'refinement' | 'distillation';
export type SettingsSuggestionSource = 'mode' | 'input' | 'manual';

export interface ModelConfig {
  temperature: number;
  topP: number;
  topK: number;
}

export interface ParameterAdvice {
  temperature?: string;
  topP?: string;
  topK?: string;
}

export interface ProcessState {
  initialPrompt: string;
  currentProduct: string | null;
  iterationHistory: IterationLogEntry[];
  currentIteration: number;
  maxIterations: number;
  isProcessing: boolean;
  finalProduct: string | null;
  statusMessage: string;
  apiKeyStatus: 'loaded' | 'missing';
  loadedFiles: LoadedFile[]; 
  promptSourceName: string | null; 
  processingMode: ProcessingMode;
  temperature: number;
  topP: number;
  topK: number;
  settingsSuggestionSource: SettingsSuggestionSource;
  userManuallyAdjustedSettings: boolean;
  modelConfigRationales: string[];
  modelParameterAdvice: ParameterAdvice;
  configAtFinalization: ModelConfig | null; 
  // Autologos Project File related state
  projectId: string | null;
  projectName: string | null;
  projectObjective: string | null;
  otherAppsData: { [appId: string]: any };
}

// Used for static details in the footer
export interface StaticAiModelDetails {
  modelName: string;
  tools: string; 
}

// Props needed by DisplayArea for generating YAML frontmatter and displaying overall summary
export interface DisplayAreaExternalProps {
  initialPromptForYAML: string;
  configAtFinalizationForYAML: ModelConfig | null; 
  staticAiModelDetailsForYAML: StaticAiModelDetails | null;
}

// For services/geminiService.ts
export interface SuggestedParamsResponse {
    config: ModelConfig;
    rationales: string[];
}

export interface ModelParameterGuidance {
    warnings: string[];
    advice: ParameterAdvice;
}

// --- Autologos Project File Format ---
export const AUTOLOGOS_PROJECT_FILE_FORMAT_VERSION = "AutologosProjectFile/1.0";
export const THIS_APP_ID = "com.autologos.iterativeengine";
export const APP_VERSION = "1.0.0"; // Or dynamically get from metadata.json

export interface ThemeHints {
  primaryColor?: string; 
  secondaryColor?: string;
  accentColor?: string;
  fontFamily?: string;
}

export interface AppManifestEntry {
  appId: string; 
  appName: string; 
  appVersion: string; 
  dataDescription: string; 
}

export interface ProjectFileHeader {
  fileFormatVersion: string; 
  projectId: string; 
  projectName: string;
  projectObjective?: string;
  createdAt: string; 
  lastModifiedAt: string; 
  lastExportedByAppId?: string; 
  lastExportedByAppVersion?: string; 
  themeHints?: ThemeHints;
  appManifest?: AppManifestEntry[];
}

// This app's specific data structure for the AutologosProjectFile
export interface AutologosIterativeEngineData {
  initialPrompt: string;
  iterationHistory: IterationLogEntry[];
  maxIterations: number;
  processingMode: ProcessingMode;
  temperature: number;
  topP: number;
  topK: number;
  finalProduct: string | null;
  currentProduct?: string | null; // If process was interrupted mid-way
  currentIteration?: number; // If process was interrupted
  promptSourceName: string | null;
  configAtFinalization: ModelConfig | null;
  loadedFiles?: LoadedFile[]; // If relevant to restore state
}

export interface AutologosProjectFile {
  header: ProjectFileHeader;
  applicationData: {
    [appId: string]: any; 
  };
}