

import React, { useState, useEffect, useCallback } from 'react';
import type { 
    IterationLogEntry, ProcessState, LoadedFile, ProcessingMode, StaticAiModelDetails, 
    SettingsSuggestionSource, ModelConfig, DisplayAreaExternalProps, ParameterAdvice, 
    SuggestedParamsResponse, ModelParameterGuidance,
    AutologosProjectFile, AutologosIterativeEngineData, ProjectFileHeader, AppManifestEntry,
    ThemeHints
} from './types';
import {
    AUTOLOGOS_PROJECT_FILE_FORMAT_VERSION, THIS_APP_ID, APP_VERSION
} from './types'; 
import * as geminiService from './services/geminiService';
import Controls from './components/Controls';
import DisplayArea from './components/DisplayArea';
import DocumentDuplicateIcon from './components/DocumentDuplicateIcon';
import ClipboardIcon from './components/ClipboardIcon'; // New Icon
import * as Diff from 'diff';


// Simple debounce hook
function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

// Safely initialize parts of the state that depend on geminiService
let safeInitialApiKeyStatus: 'loaded' | 'missing' = 'missing';
let safeInitialTemp = 0.75; 
let safeInitialTopP = 0.95; 
let safeInitialTopK = 60;   
let safeInitialModelConfigRationales: string[] = ["Using fallback default model settings for 'exploratory' mode."];

try {
  if (geminiService && typeof geminiService.isApiKeyAvailable === 'function') {
    safeInitialApiKeyStatus = geminiService.isApiKeyAvailable() ? 'loaded' : 'missing';
  } else {
    console.warn("geminiService.isApiKeyAvailable is not available. Defaulting apiKeyStatus to 'missing'.");
  }

  if (geminiService && geminiService.EXPLORATORY_MODE_DEFAULTS) {
    safeInitialTemp = geminiService.EXPLORATORY_MODE_DEFAULTS.temperature;
    safeInitialTopP = geminiService.EXPLORATORY_MODE_DEFAULTS.topP;
    safeInitialTopK = geminiService.EXPLORATORY_MODE_DEFAULTS.topK;
    safeInitialModelConfigRationales = [`Using default settings for 'exploratory' mode.`];
  } else {
    console.warn("geminiService.EXPLORATORY_MODE_DEFAULTS is not available. Using fallback model parameters.");
  }
} catch (e) {
  console.error("Error accessing geminiService during initial state setup. Using fallback defaults.", e);
}


const App: React.FC = () => {
  const [staticAiModelDetails, setStaticAiModelDetails] = useState<StaticAiModelDetails | null>(null);
  const [modelConfigWarnings, setModelConfigWarnings] = useState<string[]>([]);
  const [promptChangedByFileLoad, setPromptChangedByFileLoad] = useState(false); 
  const [specCopyStatusMessage, setSpecCopyStatusMessage] = useState<string | null>(null);


  const initialProcessState: ProcessState = {
    initialPrompt: "",
    currentProduct: null,
    iterationHistory: [],
    currentIteration: 0,
    maxIterations: 10,
    isProcessing: false,
    finalProduct: null,
    statusMessage: "Select processing mode, configure model, enter input data or load from file(s) to begin.",
    apiKeyStatus: safeInitialApiKeyStatus,
    loadedFiles: [],
    promptSourceName: null,
    processingMode: 'exploratory', 
    temperature: safeInitialTemp,
    topP: safeInitialTopP,
    topK: safeInitialTopK,
    settingsSuggestionSource: 'mode',
    userManuallyAdjustedSettings: false,
    modelConfigRationales: safeInitialModelConfigRationales,
    modelParameterAdvice: {},
    configAtFinalization: null,
    // Autologos Project File related state
    projectId: null,
    projectName: "Untitled Autologos Project",
    projectObjective: null,
    otherAppsData: {},
  };
  
  const [state, setState] = useState<ProcessState>(initialProcessState);

  const {
    initialPrompt,
    currentProduct,
    iterationHistory,
    currentIteration,
    maxIterations,
    isProcessing,
    finalProduct,
    statusMessage,
    apiKeyStatus,
    loadedFiles,
    promptSourceName,
    processingMode,
    temperature,
    topP,
    topK,
    settingsSuggestionSource,
    userManuallyAdjustedSettings,
    modelConfigRationales,
    modelParameterAdvice,
    configAtFinalization,
    projectId,
    projectName,
    projectObjective,
    otherAppsData,
  } = state;

  const debouncedInitialPrompt = useDebounce(initialPrompt, 750);

  useEffect(() => {
    try {
      if (geminiService && typeof geminiService.getStaticModelDetails === 'function') {
        setStaticAiModelDetails(geminiService.getStaticModelDetails());
      } else {
        console.warn("geminiService.getStaticModelDetails is not available. Static model details will be unavailable.");
        setStaticAiModelDetails({ modelName: "N/A", tools: "N/A" }); 
      }
    } catch (error) {
        console.error("Error getting static model details from geminiService:", error);
        setStaticAiModelDetails({ modelName: "Error", tools: "Error" }); 
    }
  }, []);

  useEffect(() => {
    try {
      if (geminiService && typeof geminiService.getModelParameterGuidance === 'function') {
        const guidance: ModelParameterGuidance = geminiService.getModelParameterGuidance({ temperature, topP, topK });
        setModelConfigWarnings(guidance.warnings);
        updateProcessState({ modelParameterAdvice: guidance.advice });
      } else {
        console.warn("geminiService.getModelParameterGuidance is not available. Model parameter advice will be unavailable.");
        setModelConfigWarnings(["Model parameter advice service not available."]);
        updateProcessState({ modelParameterAdvice: {} });
      }
    } catch (error) {
      console.error("Error getting model parameter guidance:", error);
      setModelConfigWarnings(["Error loading model parameter advice from service."]);
      updateProcessState({ modelParameterAdvice: {} }); 
    }
  }, [temperature, topP, topK]);


  const updateProcessState = (updates: Partial<ProcessState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };
  
  const getProductSummary = (product: string | undefined | null): string => {
    if (!product) return "N/A";
    const limit = 100;
    return product.length > limit ? product.substring(0, limit - 3) + "..." : product;
  };

  const addLogEntry = useCallback((logData: { iteration: number; product: string | null; status: string; previousProduct?: string | null }) => {
    let linesAdded = 0;
    let linesRemoved = 0;

    if (logData.iteration > 0 && logData.previousProduct && logData.product) {
        const changes = Diff.diffLines(logData.previousProduct, logData.product, { newlineIsToken: false, ignoreWhitespace: false });
        changes.forEach(part => {
            if (part.added) linesAdded += part.count || 0;
            if (part.removed) linesRemoved += part.count || 0;
        });
    }

    const newEntry: IterationLogEntry = {
      iteration: logData.iteration,
      productSummary: getProductSummary(logData.product),
      status: logData.status,
      timestamp: Date.now(), // Use numeric timestamp
      fullProduct: logData.product ?? undefined,
      linesAdded: linesAdded > 0 ? linesAdded : undefined,
      linesRemoved: linesRemoved > 0 ? linesRemoved : undefined,
    };
    setState(prev => {
        const existingEntryIndex = prev.iterationHistory.findIndex(entry => entry.iteration === newEntry.iteration);
        if (existingEntryIndex !== -1) {
            const updatedHistory = [...prev.iterationHistory];
            updatedHistory[existingEntryIndex] = newEntry; 
            return { ...prev, iterationHistory: updatedHistory };
        }
        return { ...prev, iterationHistory: [...prev.iterationHistory, newEntry] };
    });
  }, []);

  // Effect for mode-based default settings
  useEffect(() => {
    if (isProcessing || userManuallyAdjustedSettings) return;

    if (settingsSuggestionSource === 'mode' || !initialPrompt.trim()) {
        let baseConfig: ModelConfig | null = null;
        try {
            switch(processingMode) {
                case 'exploratory': baseConfig = geminiService.EXPLORATORY_MODE_DEFAULTS; break;
                case 'refinement': baseConfig = geminiService.REFINEMENT_MODE_DEFAULTS; break;
                case 'distillation': baseConfig = geminiService.DISTILLATION_MODE_DEFAULTS; break;
                default: baseConfig = geminiService.EXPLORATORY_MODE_DEFAULTS; // Fallback
            }
        } catch (e) {
            console.warn("Could not access default model configs from geminiService.", e);
            baseConfig = { temperature: 0.75, topP: 0.95, topK: 60 }; // Fallback generic
        }
        
        const currentRationales = [`Using default settings for '${processingMode}' mode.`];

        if (temperature !== baseConfig.temperature || topP !== baseConfig.topP || topK !== baseConfig.topK) {
            updateProcessState({ 
                temperature: baseConfig.temperature,
                topP: baseConfig.topP,
                topK: baseConfig.topK,
                settingsSuggestionSource: 'mode', 
                modelConfigRationales: currentRationales,
            });
        } else if (settingsSuggestionSource !== 'mode') { 
             updateProcessState({ 
                settingsSuggestionSource: 'mode',
                modelConfigRationales: currentRationales,
            });
        }
    }
  }, [processingMode, isProcessing, userManuallyAdjustedSettings, settingsSuggestionSource, initialPrompt, temperature, topP, topK]);

  // Effect for input-based suggested settings (debounced and content-aware)
  useEffect(() => {
    const fetchSuggestions = () => { 
        if (promptChangedByFileLoad) {
            setPromptChangedByFileLoad(false); 
            return;
        }

        if (isProcessing || userManuallyAdjustedSettings) return;
        
        if (!debouncedInitialPrompt.trim()) {
          if (settingsSuggestionSource !== 'mode') {
             let baseConfig: ModelConfig;
             try {
                switch(processingMode) {
                    case 'exploratory': baseConfig = geminiService.EXPLORATORY_MODE_DEFAULTS; break;
                    case 'refinement': baseConfig = geminiService.REFINEMENT_MODE_DEFAULTS; break;
                    case 'distillation': baseConfig = geminiService.DISTILLATION_MODE_DEFAULTS; break;
                    default: baseConfig = geminiService.EXPLORATORY_MODE_DEFAULTS;
                }
             } catch (e) { 
                console.warn("Could not access default model configs from geminiService.", e); 
                baseConfig = { temperature: 0.75, topP: 0.95, topK: 60 };
             }
              updateProcessState({
                temperature: baseConfig.temperature,
                topP: baseConfig.topP,
                topK: baseConfig.topK,
                settingsSuggestionSource: 'mode',
                modelConfigRationales: [`No prompt; using default settings for '${processingMode}' mode.`]
              });
          }
          return; 
        }

        try {
            if (geminiService && typeof geminiService.suggestModelParameters === 'function') {
                const suggestion: SuggestedParamsResponse = geminiService.suggestModelParameters(debouncedInitialPrompt, processingMode);
                updateProcessState({
                    temperature: suggestion.config.temperature,
                    topP: suggestion.config.topP,
                    topK: suggestion.config.topK,
                    settingsSuggestionSource: 'input',
                    modelConfigRationales: suggestion.rationales,
                });
            } else {
                console.warn("geminiService.suggestModelParameters is not available. Input-based suggestions disabled.");
                 updateProcessState({ settingsSuggestionSource: 'mode', modelConfigRationales: ["Model suggestion service unavailable; using mode defaults."] });
            }
        } catch (error) {
            console.error("Error fetching model parameter suggestions:", error);
            updateProcessState({ settingsSuggestionSource: 'mode', modelConfigRationales: ["Error getting suggestions; using mode defaults."] });
        }
    };
    
    fetchSuggestions();

  }, [debouncedInitialPrompt, processingMode, isProcessing, userManuallyAdjustedSettings, promptChangedByFileLoad]);


  const handleStart = async () => {
    if (!initialPrompt.trim()) {
      updateProcessState({ statusMessage: "Please enter an initial prompt or load data." });
      return;
    }
    
    updateProcessState({ 
        isProcessing: true, 
        currentIteration: 0,
        currentProduct: null, 
        finalProduct: null, 
        iterationHistory: [],
        statusMessage: "Initializing process...",
        configAtFinalization: null, // Reset this at the start
    });

    addLogEntry({ iteration: 0, product: initialPrompt, status: "Initial state set from input." });
    updateProcessState({ currentProduct: initialPrompt, statusMessage: `Starting Iteration 1 of ${maxIterations}...` });

    let currentIterProduct = initialPrompt;
    let accumulatedStreamTextForCurrentIteration = "";
    let converged = false;

    for (let i = 1; i <= maxIterations; i++) {
        updateProcessState({ currentIteration: i, statusMessage: `Processing Iteration ${i} of ${maxIterations}...` });
        accumulatedStreamTextForCurrentIteration = ""; 
        let isFirstChunkOfIteration = true;

        try {
            const iterationResult = await geminiService.iterateProduct(
                currentIterProduct,
                i,
                maxIterations,
                initialPrompt,
                processingMode,
                { temperature, topP, topK },
                (chunkText, isInitialChunk) => {
                    if (isInitialChunk) accumulatedStreamTextForCurrentIteration = ""; // Reset for new iteration
                    accumulatedStreamTextForCurrentIteration += chunkText;
                    updateProcessState({ currentProduct: accumulatedStreamTextForCurrentIteration }); 
                    if (isFirstChunkOfIteration && accumulatedStreamTextForCurrentIteration.startsWith("CONVERGED:")) {
                         updateProcessState({ statusMessage: `Iteration ${i}: AI signaled convergence early.` });
                    }
                    isFirstChunkOfIteration = false;
                }
            );
            
            currentIterProduct = iterationResult;

            if (currentIterProduct.startsWith("CONVERGED:")) {
                currentIterProduct = currentIterProduct.substring("CONVERGED:".length).trimStart();
                addLogEntry({ 
                    iteration: i, 
                    product: currentIterProduct, 
                    status: `Iteration ${i} completed. AI signaled CONVERGENCE.`,
                    previousProduct: iterationHistory.find(entry => entry.iteration === i -1)?.fullProduct
                });
                updateProcessState({ statusMessage: `Process converged at Iteration ${i}.` });
                converged = true;
                break; 
            } else {
                 addLogEntry({ 
                    iteration: i, 
                    product: currentIterProduct, 
                    status: `Iteration ${i} completed.`,
                    previousProduct: iterationHistory.find(entry => entry.iteration === i -1)?.fullProduct
                });
            }
            updateProcessState({ currentProduct: currentIterProduct });


        } catch (error: any) {
            console.error(`Error during iteration ${i}:`, error);
            const errorMessage = error.message || "An unknown error occurred during processing.";
            addLogEntry({ iteration: i, product: currentIterProduct, status: `Error in Iteration ${i}: ${errorMessage}` });
            updateProcessState({ 
                isProcessing: false, 
                finalProduct: currentIterProduct, // Save whatever was last processed
                statusMessage: `Error during Iteration ${i}: ${errorMessage}. Process halted.` 
            });
            return; 
        }
    }

    updateProcessState({ 
        isProcessing: false, 
        finalProduct: currentIterProduct,
        statusMessage: converged ? `Process completed successfully after converging at Iteration ${currentIteration}.` : `Process completed ${maxIterations} iterations.`,
        configAtFinalization: { temperature, topP, topK },
    });
  };

  const handleReset = () => {
    let modeDefaults: ModelConfig;
    let rationales: string[];
    try {
        switch(processingMode) {
            case 'exploratory': modeDefaults = geminiService.EXPLORATORY_MODE_DEFAULTS; break;
            case 'refinement': modeDefaults = geminiService.REFINEMENT_MODE_DEFAULTS; break;
            case 'distillation': modeDefaults = geminiService.DISTILLATION_MODE_DEFAULTS; break;
            default: modeDefaults = geminiService.EXPLORATORY_MODE_DEFAULTS;
        }
        rationales = [`Settings reset to defaults for '${processingMode}' mode.`];
    } catch (e) {
        console.warn("Could not access default model configs from geminiService for reset.", e);
        modeDefaults = { temperature: 0.75, topP: 0.95, topK: 60 }; // Fallback
        rationales = ["Settings reset to fallback defaults."];
    }

    updateProcessState({
      ...initialProcessState, // Reset most things
      apiKeyStatus: geminiService.isApiKeyAvailable() ? 'loaded' : 'missing', // Re-check API key
      processingMode: processingMode, // Keep current mode
      temperature: modeDefaults.temperature,
      topP: modeDefaults.topP,
      topK: modeDefaults.topK,
      settingsSuggestionSource: 'mode',
      userManuallyAdjustedSettings: false,
      modelConfigRationales: rationales,
      projectName: "Untitled Autologos Project", // Also reset project name
      projectId: null,
      projectObjective: null,
      otherAppsData: {},
    });
    setPromptChangedByFileLoad(false); 
  };

  const handleLoadedFilesChange = (newFiles: LoadedFile[]) => {
    const combinedContent = newFiles.map(f => `--- FILE: ${f.name} ---\n${f.content}`).join("\n\n---\n\n");
    const sourceName = newFiles.length > 0 ? (newFiles.length === 1 ? newFiles[0].name : `${newFiles.length}_files_combined`) : null;
    
    updateProcessState({ 
        loadedFiles: newFiles, 
        initialPrompt: combinedContent,
        promptSourceName: sourceName,
        userManuallyAdjustedSettings: false, // Allow new suggestions
    });
    setPromptChangedByFileLoad(true); // Signal that prompt changed due to file load
  };
  
  const handleInitialPromptChange = (value: string) => {
    updateProcessState({ 
        initialPrompt: value, 
        promptSourceName: loadedFiles.length > 0 ? promptSourceName : 'typed_prompt', // keep if files loaded, else typed
        userManuallyAdjustedSettings: false, // Allow new suggestions
    });
  };

  const handleMaxIterationsChange = (value: number) => {
    updateProcessState({ maxIterations: Math.max(1, value) });
  };
  
  const handleProcessingModeChange = (mode: ProcessingMode) => {
    updateProcessState({ 
        processingMode: mode,
        userManuallyAdjustedSettings: false, // Reset manual flag to get mode defaults
        settingsSuggestionSource: 'mode', // Explicitly set to mode to trigger mode defaults
    });
  };

  const handleTemperatureChange = (value: number) => {
    updateProcessState({ temperature: value, userManuallyAdjustedSettings: true, settingsSuggestionSource: 'manual' });
  };
  const handleTopPChange = (value: number) => {
    updateProcessState({ topP: value, userManuallyAdjustedSettings: true, settingsSuggestionSource: 'manual' });
  };
  const handleTopKChange = (value: number) => {
    updateProcessState({ topK: value, userManuallyAdjustedSettings: true, settingsSuggestionSource: 'manual' });
  };

  const handleRewind = (iterationNumber: number) => {
    const logEntryToRewindTo = iterationHistory.find(log => log.iteration === iterationNumber);
    if (!logEntryToRewindTo || !logEntryToRewindTo.fullProduct) {
        updateProcessState({statusMessage: `Error: Could not find full product for iteration ${iterationNumber} to rewind.`});
        return;
    }

    const newHistory = iterationHistory.filter(log => log.iteration <= iterationNumber);
    
    updateProcessState({
        initialPrompt: logEntryToRewindTo.fullProduct, // The product of that iteration becomes the new initial prompt
        currentProduct: logEntryToRewindTo.fullProduct,
        finalProduct: null, // No longer a final product
        isProcessing: false, // Stop any current processing
        currentIteration: 0, // Reset iteration count for a new run from this point
        iterationHistory: newHistory,
        statusMessage: `Rewound to Iteration ${iterationNumber}. Its product is now the initial input. Adjust settings and start a new process.`,
        promptSourceName: `rewind_iter_${iterationNumber}_${promptSourceName || 'product'}`,
        userManuallyAdjustedSettings: false, // Allow new suggestions for this new prompt
    });
    setPromptChangedByFileLoad(true); // Treat as if a file was loaded to trigger suggestions
  };

 const handleImportProject = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const text = e.target?.result as string;
            const projectData = JSON.parse(text) as AutologosProjectFile;

            // Validate header
            if (!projectData.header || projectData.header.fileFormatVersion !== AUTOLOGOS_PROJECT_FILE_FORMAT_VERSION) {
                const foundVersion = projectData.header?.fileFormatVersion || 'not specified';
                throw new Error(`Invalid or unsupported Autologos project file format. Expected "${AUTOLOGOS_PROJECT_FILE_FORMAT_VERSION}" but found "${foundVersion}".`);
            }

            const appData = projectData.applicationData?.[THIS_APP_ID] as AutologosIterativeEngineData | undefined;

            if (!appData) {
                throw new Error(`No data found for this application (ID: ${THIS_APP_ID}) in the project file.`);
            }
            
            // Apply theme hints if available (simple example)
            if (projectData.header.themeHints?.primaryColor) {
                document.documentElement.style.setProperty('--color-primary-500', projectData.header.themeHints.primaryColor);
                 // Add more theme properties as needed
            }


            updateProcessState({
                initialPrompt: appData.initialPrompt,
                currentProduct: appData.currentProduct ?? appData.finalProduct, // Prioritize current if available
                iterationHistory: appData.iterationHistory?.map(log => ({ // Ensure timestamps are numbers if old format exists
                    ...log,
                    timestamp: typeof log.timestamp === 'string' ? new Date(log.timestamp).getTime() : log.timestamp || Date.now()
                })) || [],
                currentIteration: appData.currentIteration ?? (appData.iterationHistory?.length > 0 ? Math.max(...appData.iterationHistory.map(h => h.iteration)) : 0),
                maxIterations: appData.maxIterations,
                isProcessing: false, // Always start non-processing after import
                finalProduct: appData.finalProduct,
                statusMessage: "Project loaded successfully. Review settings and continue or start new process.",
                apiKeyStatus: geminiService.isApiKeyAvailable() ? 'loaded' : 'missing',
                loadedFiles: appData.loadedFiles || [],
                promptSourceName: appData.promptSourceName || file.name,
                processingMode: appData.processingMode,
                temperature: appData.temperature,
                topP: appData.topP,
                topK: appData.topK,
                settingsSuggestionSource: 'manual', // Loaded settings are considered manual
                userManuallyAdjustedSettings: true,
                modelConfigRationales: ["Settings loaded from project file."],
                modelParameterAdvice: {}, // Will be re-evaluated by useEffect
                configAtFinalization: appData.configAtFinalization,
                projectId: projectData.header.projectId,
                projectName: projectData.header.projectName || "Untitled (from import)",
                projectObjective: projectData.header.projectObjective || null,
                otherAppsData: projectData.applicationData, // Store all other apps' data
            });
            setPromptChangedByFileLoad(true); // Trigger re-evaluation of suggestions (though 'manual' will override)
        } catch (error: any) {
            console.error("Error importing project:", error);
            updateProcessState({ statusMessage: `Error importing project: ${error.message}` });
        }
    };
    reader.onerror = (e) => {
        console.error("Failed to read project file:", e);
        updateProcessState({ statusMessage: "Error: Failed to read project file." });
    };
    reader.readAsText(file);
  };

  const handleExportProject = () => {
    const now = new Date().toISOString();
    const projectHeader: ProjectFileHeader = {
        fileFormatVersion: AUTOLOGOS_PROJECT_FILE_FORMAT_VERSION,
        projectId: projectId || `pid_${Date.now()}`, // Generate new ID if none exists
        projectName: projectName || "Untitled Autologos Project",
        projectObjective: projectObjective || undefined,
        createdAt: iterationHistory.length > 0 && iterationHistory[0].timestamp ? new Date(iterationHistory[0].timestamp).toISOString() : now, 
        lastModifiedAt: now,
        lastExportedByAppId: THIS_APP_ID,
        lastExportedByAppVersion: APP_VERSION,
        themeHints: { /* Collect actual theme hints if implemented */ },
        appManifest: [{
            appId: THIS_APP_ID,
            appName: "Autologos Iterative Engine", // Or from metadata
            appVersion: APP_VERSION,
            dataDescription: "Contains initial prompt, iteration history, model configurations, and final product from the Iterative Engine."
        }]
    };

    const thisAppData: AutologosIterativeEngineData = {
        initialPrompt,
        iterationHistory,
        maxIterations,
        processingMode,
        temperature,
        topP,
        topK,
        finalProduct,
        currentProduct: isProcessing ? currentProduct : undefined, // Only save currentProduct if processing was interrupted
        currentIteration: isProcessing ? currentIteration : undefined,
        promptSourceName,
        configAtFinalization,
        loadedFiles: loadedFiles.length > 0 ? loadedFiles : undefined,
    };
    
    // Preserve other apps' data if it exists
    const allApplicationData = {
        ...otherAppsData,
        [THIS_APP_ID]: thisAppData,
    };


    const projectFile: AutologosProjectFile = {
        header: projectHeader,
        applicationData: allApplicationData,
    };

    const fileContent = JSON.stringify(projectFile, null, 2);
    const blob = new Blob([fileContent], { type: 'application/json;charset=utf-8' });
    const safeProjectName = (projectName || "Untitled_Autologos_Project").replace(/[^a-z0-9_.-]/gi, '_');
    const fileName = `${safeProjectName}.autologos.json`;
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);

    updateProcessState({ statusMessage: `Project "${projectName}" exported as ${fileName}.`});
    if (!projectId) updateProcessState({ projectId: projectHeader.projectId }); // Persist newly generated ID
  };

  const handleProjectNameChange = (name: string) => {
    updateProcessState({ projectName: name });
  };
  
  const [theme, setTheme] = useState<'light' | 'dark'>('dark');

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  const displayAreaProps: DisplayAreaExternalProps = {
    initialPromptForYAML: initialPrompt,
    configAtFinalizationForYAML: configAtFinalization,
    staticAiModelDetailsForYAML: staticAiModelDetails,
  };


  const handleCopySpecToClipboard = () => {
    const spec = `
App State:
- Initial Prompt: ${initialPrompt.substring(0,200)}${initialPrompt.length > 200 ? '...' : ''}
- Current Product: ${currentProduct ? currentProduct.substring(0,200) + (currentProduct.length > 200 ? '...' : '') : 'N/A'}
- Final Product: ${finalProduct ? finalProduct.substring(0,200) + (finalProduct.length > 200 ? '...' : '') : 'N/A'}
- Iteration: ${currentIteration} / ${maxIterations}
- Processing Mode: ${processingMode}
- Temperature: ${temperature}, Top-P: ${topP}, Top-K: ${topK}
- Status: ${statusMessage}
- Loaded Files: ${loadedFiles.map(f=>f.name).join(', ') || 'None'}
- Project Name: ${projectName}
    `;
    navigator.clipboard.writeText(spec)
      .then(() => {
        setSpecCopyStatusMessage('App spec copied to clipboard!');
        setTimeout(() => setSpecCopyStatusMessage(null), 2000);
      })
      .catch(err => {
        console.error('Failed to copy spec: ', err);
        setSpecCopyStatusMessage('Failed to copy spec.');
        setTimeout(() => setSpecCopyStatusMessage(null), 2000);
      });
  };

  const startProcessButtonText = isProcessing ? "Processing..." : (finalProduct ? "Start New Process" : "Start Iterative Process");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-slate-100 flex flex-col antialiased">
      <header className="bg-slate-900/70 backdrop-blur-md shadow-lg p-3 sm:p-4 sticky top-0 z-50">
        <div className="container mx-auto flex flex-wrap justify-between items-center gap-2 sm:gap-4">
          <h1 className="text-xl sm:text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-secondary-500 whitespace-nowrap">
            Autologos Iterative Engine
          </h1>
          <div className="flex items-center space-x-2 sm:space-x-3">
             <button
                onClick={handleCopySpecToClipboard}
                title="Copy App State to Clipboard (for debugging/sharing)"
                className="p-1.5 sm:p-2 rounded-full text-slate-400 hover:text-primary-400 hover:bg-slate-700/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-slate-900"
                aria-label="Copy application specification to clipboard"
              >
                <ClipboardIcon className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            {specCopyStatusMessage && (
                <span className="text-xs text-primary-300 mr-2 animate-pulse" aria-live="assertive">{specCopyStatusMessage}</span>
            )}
            <button 
              onClick={toggleTheme}
              className="p-1.5 sm:p-2 rounded-full text-slate-400 hover:text-primary-400 hover:bg-slate-700/50 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-slate-900"
              title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
              aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
            >
              {theme === 'light' ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-5 sm:h-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 sm:h-5 sm:h-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.707.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 14.464A1 1 0 106.465 13.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zm1.414-9.929a1 1 0 00-1.414 0l-.707.707A1 1 0 003.636 6.465l.707-.707a1 1 0 001.414-1.414zM4 11a1 1 0 110-2H3a1 1 0 110-2h1zm10.465-3.535a1 1 0 000-1.414l-.707-.707a1 1 0 00-1.414 1.414l.707.707a1 1 0 001.414 0z" clipRule="evenodd" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="flex-grow container mx-auto p-3 sm:p-4 lg:p-6 grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-6 items-start">
        <div className="lg:col-span-1 bg-white/5 dark:bg-black/10 shadow-xl rounded-xl border border-slate-700/50 overflow-hidden">
          <Controls
            initialPromptFromApp={initialPrompt}
            onInitialPromptChange={handleInitialPromptChange}
            maxIterations={maxIterations}
            onMaxIterationsChange={handleMaxIterationsChange}
            isProcessing={isProcessing}
            onStart={handleStart}
            onReset={handleReset}
            apiKeyAvailable={apiKeyStatus === 'loaded'}
            finalProduct={finalProduct}
            loadedFilesFromApp={loadedFiles}
            onLoadedFilesChange={handleLoadedFilesChange}
            processingMode={processingMode}
            onProcessingModeChange={handleProcessingModeChange}
            temperature={temperature}
            onTemperatureChange={handleTemperatureChange}
            topP={topP}
            onTopPChange={handleTopPChange}
            topK={topK}
            onTopKChange={handleTopKChange}
            settingsSuggestionSource={settingsSuggestionSource}
            modelConfigWarnings={modelConfigWarnings}
            modelConfigRationales={modelConfigRationales}
            modelParameterAdvice={modelParameterAdvice}
            startProcessButtonText={startProcessButtonText}
            onImportProject={handleImportProject}
            onExportProject={handleExportProject}
            projectName={projectName}
            onProjectNameChange={handleProjectNameChange}
          />
        </div>
        <div className="lg:col-span-2 bg-white/5 dark:bg-black/10 shadow-xl rounded-xl border border-slate-700/50 overflow-hidden">
          <DisplayArea
            statusMessage={statusMessage}
            currentProduct={currentProduct}
            finalProduct={finalProduct}
            iterationHistory={iterationHistory}
            currentIteration={currentIteration}
            maxIterations={maxIterations}
            isProcessing={isProcessing && finalProduct === null}
            promptSourceName={promptSourceName}
            processingMode={processingMode}
            onRewind={handleRewind}
            {...displayAreaProps}
          />
        </div>
      </main>
      <footer className="text-center p-3 sm:p-4 text-xs text-slate-500 border-t border-slate-700/30">
        Autologos Iterative Engine | Model: {staticAiModelDetails?.modelName || 'Loading...'} | UI v{APP_VERSION}
      </footer>
    </div>
  );
};

export default App;