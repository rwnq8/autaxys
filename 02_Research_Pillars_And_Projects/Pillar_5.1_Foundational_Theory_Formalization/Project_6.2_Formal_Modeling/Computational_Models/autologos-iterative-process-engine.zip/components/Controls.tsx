
import React, { useRef, useState, useEffect } from 'react';
import LoadingSpinner from './LoadingSpinner';
import type { LoadedFile, ProcessingMode, SettingsSuggestionSource, ParameterAdvice } from '../types';
import InfoIcon from './InfoIcon'; 

interface ControlsProps {
  initialPromptFromApp: string;
  onInitialPromptChange: (value: string) => void;
  maxIterations: number;
  onMaxIterationsChange: (value: number) => void;
  isProcessing: boolean;
  onStart: () => void;
  onReset: () => void;
  apiKeyAvailable: boolean;
  finalProduct: string | null;
  loadedFilesFromApp: LoadedFile[];
  onLoadedFilesChange: (files: LoadedFile[]) => void;
  processingMode: ProcessingMode;
  onProcessingModeChange: (mode: ProcessingMode) => void;
  temperature: number;
  onTemperatureChange: (value: number) => void;
  topP: number;
  onTopPChange: (value: number) => void;
  topK: number;
  onTopKChange: (value: number) => void;
  settingsSuggestionSource: SettingsSuggestionSource;
  modelConfigWarnings: string[];
  modelConfigRationales: string[]; 
  modelParameterAdvice: ParameterAdvice; 
  startProcessButtonText: string; 
  onImportProject: (file: File) => void;
  onExportProject: () => void;
  projectName: string | null;
  onProjectNameChange: (name: string) => void;
}

const PlayIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className || "w-5 h-5 mr-2"}>
    <path fillRule="evenodd" d="M4.5 5.653c0-1.427 1.529-2.33 2.779-1.643l11.54 6.347c1.295.712 1.295 2.573 0 3.286L7.28 19.99c-1.25.687-2.779-.217-2.779-1.643V5.653Z" clipRule="evenodd" />
  </svg>
);

const ResetIcon: React.FC<{className?: string}> = ({className}) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 mr-2"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
  </svg>
);

const FileUploadIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 mr-2"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 16.5V9.75m0 0 3 3m-3-3-3 3M6.75 19.5a4.5 4.5 0 0 1-1.41-8.775 5.25 5.25 0 0 1 10.338-2.32 5.75 5.75 0 0 1 4.912 5.818C20.978 19.128 20.07 20 18.75 20H6.75Z" />
  </svg>
);

const DownloadIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 mr-1"}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M16.5 12 12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

const FolderOpenIcon: React.FC<{className?: string}> = ({className}) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-5 h-5 mr-2"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 9.776c.112-.017.227-.026.344-.026h15.812c.117 0 .232.009.344.026m-16.5 0a2.25 2.25 0 00-1.883 2.542l.857 6a2.25 2.25 0 002.227 1.932H19.05a2.25 2.25 0 002.227-1.932l.857-6a2.25 2.25 0 00-1.883-2.542m-16.5 0V6.75A2.25 2.25 0 015.625 4.5h3V3.75A2.25 2.25 0 0110.875 1.5h2.25A2.25 2.25 0 0115.375 3.75V4.5h3A2.25 2.25 0 0120.25 6.75v3.026c0 .414-.336.75-.75.75h-15a.75.75 0 01-.75-.75V9.776z" />
  </svg>
);


const WarningIcon: React.FC<{className?: string}> = ({className = "w-4 h-4 mr-1 inline-block"}) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
    </svg>
);

const LightbulbIcon: React.FC<{className?: string}> = ({className = "w-4 h-4 mr-1 inline-block"}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M10 2a.75.75 0 01.75.75v1.25a.75.75 0 01-1.5 0V2.75A.75.75 0 0110 2zM8.75 15.25a.75.75 0 01.75-.75h1a.75.75 0 010 1.5h-1a.75.75 0 01-.75-.75zM10 4.75a2.25 2.25 0 00-2.25 2.25c0 1.043.68 1.937 1.627 2.223V12.5a.75.75 0 001.5 0V9.223A2.24 2.24 0 0012.25 7 2.25 2.25 0 0010 4.75zM12.913 2.613a.75.75 0 01.624 1.159 7.499 7.499 0 00-5.074 8.765.75.75 0 01-1.4.527A8.999 8.999 0 0112.913 2.613zM4.142 5.32c.31-.392.21-.97-.22-1.28A8.999 8.999 0 0110 2.003V.75a.75.75 0 00-1.5 0v1.253a7.499 7.499 0 00-4.138 2.087.75.75 0 00.78 1.227z" />
    <path fillRule="evenodd" d="M5.21 16.28a.75.75 0 011.06 0l.72.72a.75.75 0 010 1.06l-.72.72a.75.75 0 01-1.06 0l-.72-.72a.75.75 0 010-1.06l.72-.72zM12.94 17.34a.75.75 0 10-1.06-1.06l-.72.72a.75.75 0 101.06 1.06l.72-.72zm2.819-2.18a.75.75 0 000-1.06l-.72-.72a.75.75 0 00-1.06 0l-.72.72a.75.75 0 101.06 1.06l.72-.72z" clipRule="evenodd" />
  </svg>
);


const Controls: React.FC<ControlsProps> = ({
  initialPromptFromApp,
  onInitialPromptChange,
  maxIterations,
  onMaxIterationsChange,
  isProcessing,
  onStart,
  onReset,
  apiKeyAvailable,
  finalProduct,
  loadedFilesFromApp,
  onLoadedFilesChange,
  processingMode,
  onProcessingModeChange,
  temperature,
  onTemperatureChange,
  topP,
  onTopPChange,
  topK,
  onTopKChange,
  settingsSuggestionSource,
  modelConfigWarnings,
  modelConfigRationales, 
  modelParameterAdvice, 
  startProcessButtonText,
  onImportProject,
  onExportProject,
  projectName,
  onProjectNameChange,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const projectFileInputRef = useRef<HTMLInputElement>(null);
  const [showModelConfigInfo, setShowModelConfigInfo] = useState(false);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const newFilePromises = Array.from(files).map(file => {
        return new Promise<LoadedFile>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            resolve({ name: file.name, content: e.target?.result as string });
          };
          reader.onerror = (e) => {
            console.error("Failed to read file:", file.name, e);
            reject(new Error(`Failed to read file: ${file.name}`));
          };
          reader.readAsText(file);
        });
      });

      try {
        const newFilesContent = await Promise.all(newFilePromises);
        onLoadedFilesChange([...loadedFilesFromApp, ...newFilesContent]);
      } catch (error) {
        console.error("Error processing files:", error);
      }
    }
    if(event.target) event.target.value = ''; 
  };

  const handleProjectFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onImportProject(file);
    }
    if (event.target) event.target.value = ''; // Reset file input
  };
  
  const getLoadedFileNamesDisplay = () => {
    if (loadedFilesFromApp.length === 0) return null;
    const MAX_DISPLAY_FILENAMES = 3;
    const names = loadedFilesFromApp.map(f => f.name);
    if (names.length > MAX_DISPLAY_FILENAMES) {
      return `Loaded: ${names.slice(0, MAX_DISPLAY_FILENAMES).join(', ')}, +${names.length - MAX_DISPLAY_FILENAMES} more`;
    }
    return `Loaded: ${names.join(', ')}`;
  }

  const modelConfigTooltipText = `Control the AI's behavior:
- Temperature: Higher (e.g., 0.9) for creative/diverse, lower (e.g., 0.2) for focused output. Range: 0.0-2.0.
- Top-P: Filters by cumulative probability (nucleus sampling). Range: 0.0-1.0.
- Top-K: Filters to K most likely tokens. Range: 1-100.`;

  const getSettingsNoteAndRationales = () => {
    let noteText = "";
    switch (settingsSuggestionSource) {
      case 'mode':
        noteText = "Values are defaults for the current mode. Adjust as needed.";
        break;
      case 'input':
        noteText = "Values suggested based on input. Feel free to override.";
        break;
      case 'manual':
        noteText = "Values manually set. Auto-suggestions paused until next mode/prompt change, file load, or reset.";
        break;
      default:
        noteText = "Adjust model parameters as needed.";
    }

    return (
      <>
        <p className="text-xs text-slate-500 dark:text-slate-400 -mt-1 mb-3">
          {noteText}
        </p>
        {(settingsSuggestionSource === 'input' || (settingsSuggestionSource === 'mode' && modelConfigRationales.length > 0)) && modelConfigRationales.length > 0 && (
          <div className="mb-3 p-3 bg-primary-50/80 dark:bg-primary-900/50 border border-primary-200 dark:border-primary-700/70 rounded-md space-y-1">
            <p className="text-xs font-semibold text-primary-700 dark:text-primary-300 flex items-center"><LightbulbIcon className="w-4 h-4 mr-1.5 flex-shrink-0" /> AI Rationale for Suggestions:</p>
            <ul className="list-disc list-inside space-y-0.5">
              {modelConfigRationales.map((rationale, index) => (
                <li key={index} className="text-xs text-primary-600 dark:text-primary-400">{rationale}</li>
              ))}
            </ul>
          </div>
        )}
      </>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <label htmlFor="projectName" className="block text-sm font-medium text-primary-600 dark:text-primary-300 mb-1">
          Project Name
        </label>
        <input
          type="text"
          id="projectName"
          value={projectName || ''}
          onChange={(e) => onProjectNameChange(e.target.value)}
          className="w-full p-3 bg-slate-50/80 dark:bg-white/5 border border-slate-300 dark:border-white/10 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 placeholder-slate-500 dark:placeholder-slate-400 text-slate-700 dark:text-slate-100"
          placeholder="Enter project name..."
          disabled={isProcessing}
          aria-label="Project Name"
        />
      </div>

      <div>
        <label htmlFor="initialPrompt" className="block text-sm font-medium text-primary-600 dark:text-primary-300 mb-1">
          Input Data / Prompt
        </label>
        <textarea
          id="initialPrompt"
          value={initialPromptFromApp} 
          onChange={(e) => onInitialPromptChange(e.target.value)} 
          rows={loadedFilesFromApp.length > 0 ? 6 : 3}
          className="w-full p-3 bg-slate-50/80 dark:bg-white/5 border border-slate-300 dark:border-white/10 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 placeholder-slate-500 dark:placeholder-slate-400 text-slate-700 dark:text-slate-100"
          placeholder="Describe the initial concept, or load from file(s)..."
          disabled={isProcessing}
          aria-label="Input Data or Prompt"
        />
        {getLoadedFileNamesDisplay() && (
          <p className="text-xs text-primary-600 dark:text-primary-400 mt-1">{getLoadedFileNamesDisplay()}</p>
        )}
      </div>
      
      <div className="grid grid-cols-2 gap-3">
         <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
          accept=".txt,.md,.json,.csv,.xml,.html,.js,.py,.java,.c,.cpp,.h,.hpp,.cs,.rb,.php,.swift,.kt,.go,.rs,.ts,.css,.scss,.less,.sh,.bat" 
          disabled={isProcessing}
          multiple
          aria-hidden="true" 
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={isProcessing}
          className="w-full inline-flex items-center justify-center px-3 py-2 border border-slate-300 dark:border-white/20 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50 focus:ring-primary-500 disabled:opacity-50 transition-colors"
          aria-label="Load input data from file(s)"
        >
          <FileUploadIcon className="w-4 h-4 mr-1.5"/>
          Load Text File(s)
        </button>

        <input
          type="file"
          ref={projectFileInputRef}
          onChange={handleProjectFileChange}
          className="hidden"
          accept=".autologos.json,.json"
          disabled={isProcessing}
          aria-hidden="true"
        />
        <button
          onClick={() => projectFileInputRef.current?.click()}
          disabled={isProcessing}
          className="w-full inline-flex items-center justify-center px-3 py-2 border border-slate-300 dark:border-white/20 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50 focus:ring-primary-500 disabled:opacity-50 transition-colors"
          aria-label="Import Autologos Project File"
        >
          <FolderOpenIcon className="w-4 h-4 mr-1.5" />
          Import Project
        </button>
      </div>

      <div>
        <label className="block text-sm font-medium text-primary-600 dark:text-primary-300 mb-2">Processing Mode</label>
        <fieldset className="space-y-2 sm:space-y-0 sm:flex sm:space-x-4 sm:flex-wrap" role="radiogroup" aria-labelledby="processing-mode-label">
          <legend id="processing-mode-label" className="sr-only">Processing Mode</legend>
          <div className="flex items-center">
            <input
              id="mode-exploratory"
              name="processingMode"
              type="radio"
              value="exploratory"
              checked={processingMode === 'exploratory'}
              onChange={() => onProcessingModeChange('exploratory')}
              disabled={isProcessing}
              className="h-4 w-4 text-primary-600 border-slate-400 dark:border-slate-500 focus:ring-primary-500 bg-white dark:bg-slate-700/50"
            />
            <label htmlFor="mode-exploratory" className="ml-2 block text-sm text-slate-700 dark:text-slate-200">
              Exploratory <span className="text-slate-500 dark:text-slate-400 text-xs">(Generate)</span>
            </label>
          </div>
          <div className="flex items-center mt-2 sm:mt-0">
            <input
              id="mode-refinement"
              name="processingMode"
              type="radio"
              value="refinement"
              checked={processingMode === 'refinement'}
              onChange={() => onProcessingModeChange('refinement')}
              disabled={isProcessing}
              className="h-4 w-4 text-primary-600 border-slate-400 dark:border-slate-500 focus:ring-primary-500 bg-white dark:bg-slate-700/50"
            />
            <label htmlFor="mode-refinement" className="ml-2 block text-sm text-slate-700 dark:text-slate-200">
              Refinement <span className="text-slate-500 dark:text-slate-400 text-xs">(Improve)</span>
            </label>
          </div>
          <div className="flex items-center mt-2 sm:mt-0">
            <input
              id="mode-distillation"
              name="processingMode"
              type="radio"
              value="distillation"
              checked={processingMode === 'distillation'}
              onChange={() => onProcessingModeChange('distillation')}
              disabled={isProcessing}
              className="h-4 w-4 text-primary-600 border-slate-400 dark:border-slate-500 focus:ring-primary-500 bg-white dark:bg-slate-700/50"
            />
            <label htmlFor="mode-distillation" className="ml-2 block text-sm text-slate-700 dark:text-slate-200">
              Distillation <span className="text-slate-500 dark:text-slate-400 text-xs">(Simplify)</span>
            </label>
          </div>
        </fieldset>
      </div>
      
      <div className="space-y-4 pt-4 border-t border-slate-300/70 dark:border-white/10">
        <div className="flex items-center mb-1 relative">
            <h3 className="text-md font-semibold text-primary-600 dark:text-primary-300 mr-2">Model Configuration</h3>
            <div 
              className="relative"
              onMouseEnter={() => setShowModelConfigInfo(true)}
              onMouseLeave={() => setShowModelConfigInfo(false)}
              onFocus={() => setShowModelConfigInfo(true)}
              onBlur={() => setShowModelConfigInfo(false)}
              tabIndex={0}
              aria-describedby="model-config-tooltip"
            >
              <InfoIcon className="w-4 h-4 text-primary-500 dark:text-primary-400 cursor-pointer" />
              {showModelConfigInfo && (
                <div
                  id="model-config-tooltip"
                  role="tooltip" 
                  className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-72 bg-white/95 dark:bg-slate-800/90 backdrop-blur-sm text-slate-700 dark:text-slate-200 text-xs p-3 rounded-md shadow-lg z-20 border border-slate-300/70 dark:border-white/20"
                >
                  {modelConfigTooltipText.split('\n').map((line, i) => <p key={i} className={line.startsWith('-') ? 'ml-2' : ''}>{line}</p>)}
                </div>
              )}
            </div>
        </div>
        
        {getSettingsNoteAndRationales()}

        {modelConfigWarnings.length > 0 && (
            <div className="p-3 bg-yellow-100/80 dark:bg-yellow-500/30 border border-yellow-400/80 dark:border-yellow-500/50 rounded-md mb-3 space-y-1">
                {modelConfigWarnings.map((warning, index) => (
                    <p key={index} className="text-xs text-yellow-700 dark:text-yellow-200 flex items-start">
                        <WarningIcon className="w-4 h-4 mr-2 flex-shrink-0 mt-px" />
                        <span>{warning}</span>
                    </p>
                ))}
            </div>
        )}

        <div>
            <label htmlFor="temperature" className="block text-sm font-medium text-primary-600 dark:text-primary-400 mb-1">
            Temperature: <span className="text-slate-800 dark:text-slate-100 font-mono">{temperature.toFixed(2)}</span>
            </label>
            <input
            type="range"
            id="temperature"
            min="0"
            max="2"
            step="0.01" 
            value={temperature}
            onChange={(e) => onTemperatureChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-200 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary-500 dark:accent-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50"
            disabled={isProcessing}
            aria-label="Temperature setting"
            />
            {modelParameterAdvice.temperature && <p className="text-xs text-primary-600 dark:text-primary-200 mt-1">{modelParameterAdvice.temperature}</p>}
        </div>
        <div>
            <label htmlFor="topP" className="block text-sm font-medium text-primary-600 dark:text-primary-400 mb-1">
            Top-P: <span className="text-slate-800 dark:text-slate-100 font-mono">{topP.toFixed(2)}</span>
            </label>
            <input
            type="range"
            id="topP"
            min="0"
            max="1"
            step="0.01"
            value={topP}
            onChange={(e) => onTopPChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-200 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary-500 dark:accent-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50"
            disabled={isProcessing}
            aria-label="Top-P setting"
            />
            {modelParameterAdvice.topP && <p className="text-xs text-primary-600 dark:text-primary-200 mt-1">{modelParameterAdvice.topP}</p>}
        </div>
        <div>
            <label htmlFor="topK" className="block text-sm font-medium text-primary-600 dark:text-primary-400 mb-1">
            Top-K: <span className="text-slate-800 dark:text-slate-100 font-mono">{topK}</span>
            </label>
            <input
            type="range"
            id="topK"
            min="1"
            max="100" 
            step="1"
            value={topK}
            onChange={(e) => onTopKChange(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-slate-200 dark:bg-white/10 rounded-lg appearance-none cursor-pointer accent-primary-500 dark:accent-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50"
            disabled={isProcessing}
            aria-label="Top-K setting"
            />
            {modelParameterAdvice.topK && <p className="text-xs text-primary-600 dark:text-primary-200 mt-1">{modelParameterAdvice.topK}</p>}
        </div>
      </div>


      <div>
        <label htmlFor="maxIterations" className="block text-sm font-medium text-primary-600 dark:text-primary-300 mb-1">
          Max Iterations
        </label>
        <input
          type="number"
          id="maxIterations"
          value={maxIterations}
          onChange={(e) => onMaxIterationsChange(Math.max(1, parseInt(e.target.value, 10) || 1))}
          min="1"
          max="100"
          className="w-full p-3 bg-slate-50/80 dark:bg-white/5 border border-slate-300 dark:border-white/10 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 text-slate-700 dark:text-slate-100"
          disabled={isProcessing}
          aria-label="Maximum number of iterations"
        />
      </div>

      <div className="flex flex-col space-y-3">
        <button
          onClick={onStart}
          disabled={isProcessing || !apiKeyAvailable || !initialPromptFromApp.trim()}
          className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50 focus:ring-primary-500 disabled:bg-slate-400 dark:disabled:bg-slate-600/70 disabled:cursor-not-allowed transition-colors"
          aria-label={startProcessButtonText}
        >
          {isProcessing ? (
            <>
              <LoadingSpinner size="sm" color="text-white"/>
              <span className="ml-2">Processing...</span>
            </>
          ) : (
            <>
              <PlayIcon />
              {startProcessButtonText}
            </>
          )}
        </button>
        <div className="flex space-x-3">
          <button
            onClick={onReset} 
            disabled={isProcessing && finalProduct === null} 
            className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-slate-300 dark:border-white/20 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            aria-label="Reset all inputs, results, and model settings to defaults for the current mode"
          >
            <ResetIcon className="w-4 h-4 mr-1.5"/>
            Reset
          </button>
          <button
            onClick={onExportProject}
            disabled={isProcessing}
            className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-slate-300 dark:border-white/20 text-sm font-medium rounded-md shadow-sm text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-white/10 hover:bg-slate-200 dark:hover:bg-white/20 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-black/50 focus:ring-primary-500 disabled:opacity-50 transition-colors"
            aria-label="Export Autologos Project File"
          >
            <DownloadIcon className="w-4 h-4 mr-1.5" />
            Export Project
          </button>
        </div>
      </div>
      {!apiKeyAvailable && (
        <p className="text-xs text-yellow-600 dark:text-yellow-300 text-center mt-2">
          Warning: API_KEY is not configured. The AI process cannot start.
        </p>
      )}
    </div>
  );
};

export default Controls;